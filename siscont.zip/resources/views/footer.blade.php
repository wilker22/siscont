<div>
    <footer
        class="fixed bottom-0 left-0 z-20 w-full p-1 bg-white border-t
                border-gray-200 shadow
                md:flex
                md:items-center
                md:justify-between
                md:p-2 dark:bg-gray-800
                dark:border-gray-600">
        <span class="text-right text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2024
            <a href="https://siscon.wtech.eti.br" class="hover:underline">Desenvolvido por: 3ª GRG/UMC - Equipe de
                Monitoramento da 3ª SR
                CODEVASF</a>.
        </span>
    </footer>
</div>
