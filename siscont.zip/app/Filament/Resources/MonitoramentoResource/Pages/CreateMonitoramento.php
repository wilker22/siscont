<?php

namespace App\Filament\Resources\MonitoramentoResource\Pages;

use App\Filament\Resources\MonitoramentoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMonitoramento extends CreateRecord
{
    protected static string $resource = MonitoramentoResource::class;
}
