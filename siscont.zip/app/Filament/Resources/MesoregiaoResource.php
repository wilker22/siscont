<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MesoregiaoResource\Pages;
use App\Filament\Resources\MesoregiaoResource\RelationManagers;
use App\Models\Mesoregiao;
use Filament\Forms;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class MesoregiaoResource extends Resource
{
    protected static ?string $model = Mesoregiao::class;

    protected static ?string $navigationIcon = 'heroicon-o-map';
    protected static ?string $recordTitleAttribute = 'name';

    protected static ?string $navigationGroup = 'Cadastros';

    protected static ?string $navigationLabel = 'Mesorregião';

    protected static ?int $navigationSort = 3;


    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('nome')->required(),
                RichEditor::make('descricao'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('nome')->searchable(),

            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                // Tables\Actions\BulkActionGroup::make([
                //     Tables\Actions\DeleteBulkAction::make(),
                // ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMesoregiaos::route('/'),
            'create' => Pages\CreateMesoregiao::route('/create'),
            'edit' => Pages\EditMesoregiao::route('/{record}/edit'),
        ];
    }
}
