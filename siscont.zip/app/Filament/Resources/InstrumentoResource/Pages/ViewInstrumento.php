<?php

namespace App\Filament\Resources\InstrumentoResource\Pages;

use App\Filament\Resources\InstrumentoResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewInstrumento extends ViewRecord
{
    protected static string $resource = InstrumentoResource::class;
}
