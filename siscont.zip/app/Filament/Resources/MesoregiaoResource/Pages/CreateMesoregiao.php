<?php

namespace App\Filament\Resources\MesoregiaoResource\Pages;

use App\Filament\Resources\MesoregiaoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMesoregiao extends CreateRecord
{
    protected static string $resource = MesoregiaoResource::class;
}
