<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.fiscal-resource.pages.create-fiscal' => 'App\\Filament\\Resources\\FiscalResource\\Pages\\CreateFiscal',
    'app.filament.resources.fiscal-resource.pages.edit-fiscal' => 'App\\Filament\\Resources\\FiscalResource\\Pages\\EditFiscal',
    'app.filament.resources.fiscal-resource.pages.list-fiscals' => 'App\\Filament\\Resources\\FiscalResource\\Pages\\ListFiscals',
    'app.filament.resources.instrumento-resource.pages.create-instrumento' => 'App\\Filament\\Resources\\InstrumentoResource\\Pages\\CreateInstrumento',
    'app.filament.resources.instrumento-resource.pages.edit-instrumento' => 'App\\Filament\\Resources\\InstrumentoResource\\Pages\\EditInstrumento',
    'app.filament.resources.instrumento-resource.pages.list-instrumentos' => 'App\\Filament\\Resources\\InstrumentoResource\\Pages\\ListInstrumentos',
    'app.filament.resources.mesoregiao-resource.pages.create-mesoregiao' => 'App\\Filament\\Resources\\MesoregiaoResource\\Pages\\CreateMesoregiao',
    'app.filament.resources.mesoregiao-resource.pages.edit-mesoregiao' => 'App\\Filament\\Resources\\MesoregiaoResource\\Pages\\EditMesoregiao',
    'app.filament.resources.mesoregiao-resource.pages.list-mesoregiaos' => 'App\\Filament\\Resources\\MesoregiaoResource\\Pages\\ListMesoregiaos',
    'app.filament.resources.monitoramento-resource.pages.create-monitoramento' => 'App\\Filament\\Resources\\MonitoramentoResource\\Pages\\CreateMonitoramento',
    'app.filament.resources.monitoramento-resource.pages.edit-monitoramento' => 'App\\Filament\\Resources\\MonitoramentoResource\\Pages\\EditMonitoramento',
    'app.filament.resources.monitoramento-resource.pages.list-monitoramentos' => 'App\\Filament\\Resources\\MonitoramentoResource\\Pages\\ListMonitoramentos',
    'app.filament.resources.municipio-resource.pages.create-municipio' => 'App\\Filament\\Resources\\MunicipioResource\\Pages\\CreateMunicipio',
    'app.filament.resources.municipio-resource.pages.edit-municipio' => 'App\\Filament\\Resources\\MunicipioResource\\Pages\\EditMunicipio',
    'app.filament.resources.municipio-resource.pages.list-municipios' => 'App\\Filament\\Resources\\MunicipioResource\\Pages\\ListMunicipios',
    'app.filament.resources.unidade-resource.pages.create-unidade' => 'App\\Filament\\Resources\\UnidadeResource\\Pages\\CreateUnidade',
    'app.filament.resources.unidade-resource.pages.edit-unidade' => 'App\\Filament\\Resources\\UnidadeResource\\Pages\\EditUnidade',
    'app.filament.resources.unidade-resource.pages.list-unidades' => 'App\\Filament\\Resources\\UnidadeResource\\Pages\\ListUnidades',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
    'filament.pages.auth.register' => 'Filament\\Pages\\Auth\\Register',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\siscont\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\xampp\\htdocs\\siscont\\app\\Filament\\Resources\\FiscalResource.php' => 'App\\Filament\\Resources\\FiscalResource',
    'C:\\xampp\\htdocs\\siscont\\app\\Filament\\Resources\\InstrumentoResource.php' => 'App\\Filament\\Resources\\InstrumentoResource',
    'C:\\xampp\\htdocs\\siscont\\app\\Filament\\Resources\\MesoregiaoResource.php' => 'App\\Filament\\Resources\\MesoregiaoResource',
    'C:\\xampp\\htdocs\\siscont\\app\\Filament\\Resources\\MonitoramentoResource.php' => 'App\\Filament\\Resources\\MonitoramentoResource',
    'C:\\xampp\\htdocs\\siscont\\app\\Filament\\Resources\\MunicipioResource.php' => 'App\\Filament\\Resources\\MunicipioResource',
    'C:\\xampp\\htdocs\\siscont\\app\\Filament\\Resources\\UnidadeResource.php' => 'App\\Filament\\Resources\\UnidadeResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\siscont\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\siscont\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);